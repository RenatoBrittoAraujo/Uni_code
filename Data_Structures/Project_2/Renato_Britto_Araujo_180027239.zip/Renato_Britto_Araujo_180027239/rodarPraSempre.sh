#!/bin/bash
while :
    do
        ./a.out
done
